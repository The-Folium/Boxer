#pragma once
#include "Menu.h"
#include "Tournament.h"
#include "Settings.h"

class Game
{
	Tournament tournament;
	
public:
	
	void run();
};