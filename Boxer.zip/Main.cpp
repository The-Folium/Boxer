#include "Log.h"
#include "Settings.h"
#include "Game.h"

Logger Log;
Settings settings;

int main()
{
	Game game;
	game.run();	
}